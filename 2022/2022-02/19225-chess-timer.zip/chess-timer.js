function set_led_player_1(state){
    document.getElementById('p1-led').setAttribute('visibility', state ? 'visible' : 'hidden');
}

function set_led_player_2(state){
    document.getElementById('p2-led').setAttribute('visibility', state ? 'visible' : 'hidden');
}


function set_active_player(p){
    if (p == 1){
        set_led_player_1(true);
        set_led_player_2(false);
    } else {
        set_led_player_1(false);
        set_led_player_2(true);
    }
}


var current_player = 1;
function toggle_player_led(){
    if (current_player == 1)
        current_player = 2;
    else
        current_player = 1;

    set_active_player(current_player);
}

function init_chess_timer(){
    setInterval(toggle_player_led, 1000);
}
