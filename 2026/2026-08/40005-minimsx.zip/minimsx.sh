#!/bin/sh
# Run the MSX emulator interactively.  usage: ./minimsx.sh [cart.rom]
#
# MSX1 emulator, supports rom, megarom and SCC.
# ESC quits.
#
# Without an argument the machine boots to BASIC or the C-BIOS logo. 
# ROM filenames must fit DOS 8.3 -- salamander.rom won't load, salame.rom will.
set -e
cd "$(dirname "$0")"
dosbox -c "mount c $PWD" -c "c:" -c "config -set cpu core=dynamic" -c "config -set cpu cycles=max" -c "msx.com $1"
