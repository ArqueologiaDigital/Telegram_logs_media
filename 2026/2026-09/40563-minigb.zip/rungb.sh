#!/bin/sh
# rungb.sh [cart] [image] -- boot a cartridge under DOSBox, to watch and play.
#
#   ./rungb.sh                          the default cartridge
#   ./rungb.sh roms/mario1.zip
#   ./rungb.sh roms/tetris.zip gbu.com  the unpacked image, for A/B
#
# The library is short names -- roms/NAMES.txt says which dump each one is.
#
# The cartridge may be a .gb or a .zip holding one: the ROM library ships as
# zips and unpacking each one by hand before playing it was the only step
# between having a cartridge and running it.
#
# Keys: arrows = the pad, Z = A, X = B, Enter = Start, Space = Select,
# Esc = quit -- the emulator's own int 9 handler sees it and exits cleanly,
# giving the keyboard vector and the text mode back.
#
# Plain dosbox, always -- see dosbox.py. gb.com is the packed image that
# ships; gbu.com is the same image unpacked, for when something works one
# way and not the other.
set -e
cd "$(dirname "$0")"
ROM=${1:-roms/tetris.zip}
BIN=${2:-gb.com}
test -f "$ROM" || { echo "rungb: no such cartridge: $ROM" >&2; exit 1; }
test -f "$BIN" || { echo "rungb: no such image: $BIN -- run ./build.sh" >&2; exit 1; }

D=$(mktemp -d)
trap 'rm -rf "$D"' EXIT
cp "$BIN" "$D/gb.com"

case "$ROM" in
*.zip|*.ZIP)
    # take the first ROM in the archive; these dumps hold exactly one
    command -v unzip >/dev/null || { echo "rungb: unzip not installed" >&2; exit 1; }
    # everything, then pick by extension: naming the patterns to unzip makes
    # it print a `caution: filename not matched' for each one that is not in
    # the archive, and under `set -e' the warning status ends the script
    unzip -o -j -q "$ROM" -d "$D/z"
    INNER=$(find "$D/z" -maxdepth 1 -type f \
                 \( -iname '*.gb' -o -iname '*.gbc' \) | sort | head -1)
    test -n "$INNER" || { echo "rungb: no .gb inside $ROM" >&2; exit 1; }
    echo "rungb: $(basename "$INNER")"
    cp "$INNER" "$D/cart.gb"
    ;;
*)  cp "$ROM" "$D/cart.gb" ;;
esac

exec dosbox -c "mount c $D" -c c: \
            -c "config -set cpu core=dynamic" \
            -c "config -set cpu cycles=max" \
            -c "gb.com cart.gb"
