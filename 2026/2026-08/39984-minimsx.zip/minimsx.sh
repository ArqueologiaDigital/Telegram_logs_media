#!/bin/sh
# Run the MSX emulator interactively.  usage: ./minimsx.sh [cart.rom]
#
# The whole MSX keyboard is mapped from the PC's, so games that want letters
# or the function keys get them; arrows and space work as you would expect.
# ESC quits.  Without an argument the machine boots with no cartridge.
set -e
cd "$(dirname "$0")"
dosbox -c "mount c $PWD" -c "c:" -c "config -set cpu core=dynamic" -c "config -set cpu cycles=max" -c "msx.com $1"
