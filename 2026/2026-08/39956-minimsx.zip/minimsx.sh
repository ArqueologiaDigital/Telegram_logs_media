#!/bin/sh
# Run the MSX emulator interactively.  usage: ./runmsx.sh [cart.rom]
# Keys: arrows = joystick, space = trigger, ESC = quit.
set -e
cd "$(dirname "$0")"
dosbox -c "mount c $PWD" -c "c:" -c "config -set cpu core=dynamic" -c "config -set cpu cycles=max" -c "msx.com $1"
